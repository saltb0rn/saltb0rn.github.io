import { 
  OrbitControls,
  OrthographicCamera,
  useFBO,
  Effects,
  useGLTF,
} from "@react-three/drei";
import { Canvas, useFrame, extend } from "@react-three/fiber";
import { useControls } from "leva";

import { Pass } from "postprocessing";
import { Suspense, useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { v4 as uuidv4 } from "uuid";
import fragmentShader from "!!raw-loader!./fragmentShader.glsl";
import { Plant, Spaceship } from "./Models";

import './scene.css';

const kuwaharaShader = {
  uniforms: {
    inputBuffer: { value: null },
    resolution: {
      value: new THREE.Vector4(),
    },
    radius: { value: 10.0 },
  },
  vertexShader: `
  varying vec2 vUv;

  void main() {
    vUv = uv;
    vec4 modelViewPosition = modelViewMatrix * vec4(position, 1.0);
   

    // Set the final position of the vertex
    gl_Position = projectionMatrix * modelViewPosition;
  }
  `,
  fragmentShader,
};

class KuwaharaPass extends Pass {
  constructor(args) {
    super();

    this.material = new THREE.ShaderMaterial(kuwaharaShader);
    this.fullscreenMaterial = this.material;
    this.resolution = new THREE.Vector4(
      window.innerWidth * Math.min(window.devicePixelRatio, 2),
      window.innerHeight * Math.min(window.devicePixelRatio, 2),
      1 / (window.innerWidth * Math.min(window.devicePixelRatio, 2)),
      1 / (window.innerHeight * Math.min(window.devicePixelRatio, 2))
    );
    this.radius = args.radius;
  }

  dispose() {
    this.material.dispose();
  }

  render(renderer, writeBuffer, readBuffer) {
    this.material.uniforms.resolution.value = new THREE.Vector4(
      window.innerWidth * Math.min(window.devicePixelRatio, 2),
      window.innerHeight * Math.min(window.devicePixelRatio, 2),
      1 / (window.innerWidth * Math.min(window.devicePixelRatio, 2)),
      1 / (window.innerHeight * Math.min(window.devicePixelRatio, 2))
    );
    this.material.uniforms.radius.value = this.radius;
    this.material.uniforms.inputBuffer.value = readBuffer.texture;

    if (this.renderToScreen) {
      renderer.setRenderTarget(null);
      renderer.render(this.scene, this.camera);
    } else {
      renderer.setRenderTarget(writeBuffer);
      if (this.clear) renderer.clear();
      renderer.render(this.scene, this.camera);
    }
  }
}


extend({ KuwaharaPass });

const Painting = () => {
  const kuwaharaPassRef = useRef();

  const { enabled, radius, model } = useControls({
    enabled: true,
    radius: { value: 15, min: 1, max: 35, step: 1 },
    model: {
        value: "spaceship",
        options: ["spaceship", "plant"],
    }
  });

  useFrame((state) => {
    const { camera } = state;
    kuwaharaPassRef.current.radius = radius;
    kuwaharaPassRef.current.enabled = enabled;
    camera.lookAt(0, 0, 0);
  });

  return (
    <>
      <group scale={0.70}>
        {model === "spaceship" ? <Spaceship /> : <Plant />}
      </group>
      <Effects key={uuidv4()}>
        <kuwaharaPass 
          ref={kuwaharaPassRef}
          args={[{
            radius
          }]}
        />
      </Effects>
    </>
  );
};

const Scene = () => {
  return (
    <Canvas dpr={[1, 2]}>
      <Suspense fallback="Loading">
        <ambientLight intensity={1.25} />
        <color attach="background" args={["#3386E0"]} />
        <Painting />
        <OrbitControls />
        <OrthographicCamera
          makeDefault
          position={[5, 0, 10]}
          zoom={100}
          near={0.01}
          far={500}
        />
      </Suspense>
    </Canvas>
  );
};


export default Scene;