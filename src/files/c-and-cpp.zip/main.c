#include <stdio.h>

extern int c_add(int, int);
extern int cpp_sub(int, int);

int main() {
  fprintf(stdout, "%d + %d = %d\n", 1, 2, c_add(1, 2));
  fprintf(stdout, "%d - %d = %d\n", 1, 2, cpp_sub(1, 2));
  return 0;
}
