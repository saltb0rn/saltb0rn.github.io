#include <iostream>

extern "C" int c_add(int, int);   // CPP 引用 C 符号得使用 extern "C" 来声明
extern "C" int cpp_sub(int, int); // 即使是 CPP 引用 CPP 模块导出的 C 符号， 也得需要使用 extern "C" 来声明

// 有多个引用时可以使用下面这种写法

// extern "C" {
//   int c_add(int, int);
//   int cpp_sub(int, int);
// }

int main() {
  std::cout << "1 + 2 = " << c_add(1, 2) << std::endl;
  std::cout << "1 - 2 = " << cpp_sub(1, 2) << std::endl;
  return 0;
}
