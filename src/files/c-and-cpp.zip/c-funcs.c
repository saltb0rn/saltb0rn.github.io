int c_add(int x, int y) {
  return x + y;
}
