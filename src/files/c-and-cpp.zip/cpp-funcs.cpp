extern "C" {
  // 以 C 符号的形式导出
  int cpp_sub(int, int);
}

int cpp_sub(int x, int y) {
  return x - y;
}
